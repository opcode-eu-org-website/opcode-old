Jest to sterownik wirtualnej klawiatury, umożliwiającej odbieranie znaków i key-kodów wpisywanych do urządzenia w /dev tak jakby przychodziły z podsystemu input od rzeczywistej lokalnej klawiatury.

Sterownik został zrealizowany w ramach małego projektu na przedmiot "Sterowniki urządzeń - podstawy programowania" prowadzonego w semestrze letnim 2008/9 na Wydziale Elektroniki i Technik Informacyjnych Politechniki Warszawskiej.

Projekt zawiera fragmenty silnie oparte na kodzie jądra Linuxa. Projekt dystrybuowany na zasadach licencji GNU GPL.

Robert Paciorek,
2009-06-15
