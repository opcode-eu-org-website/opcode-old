/**
 * jest to sterownik wirtualnej klawiatury
 * używa się jej za pomocą utworzonego przez ten moduł pliku urządzenia /dev/vkbd0
 *
 * można wpisywać dane jako ASCII ( tylko znaki z zakresu od 0x20 do 0x7e:
 *   echo -n "A l a   m a   k o t a   0 x 6 a" > /dev/vkbd0
 * działa przy założeniu że korzystamy z mapy klawiatury zgodnej z US
 *
 * lub podając keycody zgodne z przyciskami na skonfigurowanej klawiaturze:
 *   echo -n "0x36 0x1e 0x9e 0xb6 0x26 0xa6" > /dev/vkbd0
 * odczytać je można z pliku mapy klawiatury lub przy pomocy `showkey`
 * należy pamiętać o podanie keycodu oznaczającego odpuszczenie przycisku
 *
 * można także mieszać oba sposoby:
 *   echo -n "0x36 0x1e 0x9e 0xb6 l a   m a   k o t a" > /dev/vkbd0
 *
 * spacje pomiędzy kolejnymi znakami ascii lub keycodami są wymagane
 *
 **/

#include <linux/kernel.h>
#include <linux/module.h>

#include <linux/device.h>
#include <linux/fs.h>
#include <linux/cdev.h>
#include <linux/input.h>

#include <asm/uaccess.h>


// informacje o naszym module
#define DEVICE_CLASS_NAME "vkbd"
#define DEVICE_NAME "vkbd"
MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("Virtual keyboard driver");
MODULE_AUTHOR("Robert Paciorek");


int vkbd_init(void);
module_init(vkbd_init);

void vkbd_cleanup(void);
module_exit(vkbd_cleanup);


static ssize_t char_dev_write( struct file *file, const char __user *buf, size_t count, loff_t *ppos );
static int char_dev_open (struct inode *inode, struct file *file);


// struktury opisujące urządzenie znakowege i jego klasę
static struct class *vkbd_class = NULL;
static dev_t vkbd_dev = 0;
static struct cdev *vkbd_cdev = NULL;

// struktura ustawien pliku urzadzenia znakowego
static struct file_operations char_dev_conf = {
	.owner	 = THIS_MODULE,
	.write	 = char_dev_write, // tutaj określamy funkcję wywoływaną przy zapisie
	.open	 = char_dev_open, // ... przy otwarciu
};

static struct input_dev *input_dev = NULL;

int vkbd_init( void ) {
	int err;
	
	printk(KERN_DEBUG "Create device\n");
	
	// tworzymy strukturę opisującą obsługę urządzenia znakowego
	vkbd_cdev = cdev_alloc();
	vkbd_cdev->ops = &char_dev_conf;
	vkbd_cdev->owner = THIS_MODULE;
	
	// uzyskujemy numer dla urządzenia
	err=alloc_chrdev_region(&vkbd_dev, 0, 1, DEVICE_NAME);
	if(err) {
		printk ("<1>Error alocation device number for %s (%d)\n", DEVICE_NAME, err);
		vkbd_cleanup();
		return err;
	};
	
	// dodajemy urządzenie znakowe w systemie
	err=cdev_add(vkbd_cdev, vkbd_dev, 1);
	if(err) {
		printk ("<1>Error registration device number for %s (%d)\n", DEVICE_NAME, err);
		vkbd_cleanup();
		return err;
	};
	
	// tworzymy klasę urządzenia
	vkbd_class = class_create(THIS_MODULE, DEVICE_CLASS_NAME);
	if (IS_ERR(vkbd_class)) {
		err=PTR_ERR(vkbd_class);
		printk(KERN_ERR "Error creating %s device class (%d).\n", DEVICE_CLASS_NAME, err);
		vkbd_cleanup();
		return err;
	}
	
	// tworzymu urządzenie i rejestrujemy je w sysfs (/sys)
	device_create(vkbd_class, NULL, vkbd_dev, NULL, "vkbd%d", MINOR(vkbd_dev));
	
	printk(KERN_DEBUG "Finish create device ... now register in input subsystem\n");
	

	input_dev = input_allocate_device();
	if (!input_dev) {
		printk(KERN_ERR "Error allocate input device struct.\n");
		vkbd_cleanup();
		return -ENOMEM;;
	}
	input_dev->name = "Virtual Keybord Device";
	input_dev->evbit[0] = BIT_MASK(EV_KEY) | BIT_MASK(EV_REP);
	for (err = 0; err < 255; err++)
		set_bit(err, input_dev->keybit);
	
	err = input_register_device(input_dev);
	if(err) {
		printk(KERN_ERR "Error register %s in input subsystem (%d).\n", DEVICE_CLASS_NAME, err);
		vkbd_cleanup();
		return err;
	}
	
	printk(KERN_DEBUG "Finish register in input subsystem\n");

	
	return 0;
}

void vkbd_cleanup(void) {
	if (input_dev) {
		//input_get_device(input_dev);
		input_unregister_device(input_dev);
		input_free_device(input_dev);
	}
	
	if(vkbd_dev && vkbd_class) {
		device_destroy(vkbd_class,vkbd_dev);
	}
	
	if(vkbd_cdev) {
		cdev_del(vkbd_cdev);
		vkbd_cdev=NULL;
	}
	
	unregister_chrdev_region(vkbd_dev, 1);
	
	if(vkbd_class) {
		class_destroy(vkbd_class);
		vkbd_class=NULL;
	}
}

// keycode znaków ascii, 0x80 koduje że znak uzyskiwany z shiftem
static unsigned char ascii_to_code[95] = {
	0x39, 0x82, 0xa8, 0x84,   0x85, 0x86, 0x88, 0x8a, //   ! " #   $ % & '
	0x28, 0x8b, 0x89, 0x8d,   0x33, 0x0c, 0x34, 0x35, // ( ) * +   , - . /
	0x0b, 0x02, 0x03, 0x04,   0x05, 0x06, 0x07, 0x08, // 0 1 2 3   4 5 6 7
	0x09, 0x0a, 0xa7, 0x27,   0xb3, 0x0d, 0xb4, 0xb5, // 8 9 : ;   < = > ?
	0x83, 0x9e, 0xb0, 0xae,   0xa0, 0x92, 0xa1, 0xa2, // @ A B C   D E F G
	0xa3, 0x97, 0xa4, 0xa5,   0xa6, 0xb2, 0xb1, 0x98, // H I J K   L M N O
	0x99, 0x90, 0x93, 0x9f,   0x94, 0x96, 0xaf, 0x91, // P Q R S   T U V W
	0xad, 0x95, 0xac, 0x1a,   0x2b, 0x1b, 0x87, 0x8c, // X Y Z [   \ ] ^ _
	0x29, 0x1e, 0x30, 0x2e,   0x20, 0x12, 0x21, 0x22, // ` a b c   d e f g
	0x23, 0x17, 0x24, 0x25,   0x26, 0x32, 0x31, 0x18, // h i j k   l m n o
	0x19, 0x10, 0x13, 0x1f,   0x14, 0x16, 0x2f, 0x11, // p q r s   t u v w
	0x2d, 0x15, 0x2c, 0x9a,   0xab, 0x9b, 0xa9        // x y z {   | } ~
};

static ssize_t char_dev_write( struct file *file, const char __user *buf, size_t count, loff_t *ppos ) {
	int i, val, val2;
	char *end;
	
	printk(KERN_DEBUG "write %d bytes\n", count);
	
	for (i=0; i<count;) {
		// gdy powinien to byc znak ASCII
		if (i == count-1 || buf[i+1] == ' ') {
			// pobranie kodu ASCII
			val = buf[i];
			// sprawdzenie czy dopuszczalny kod
			if (val > 0x1f && val < 0x7f) {
				printk(KERN_DEBUG "generuje znak %d (%c) %d\n", val, val, i);
				
				// reskalowanie do drukowalnego podzakresu ASCII
				val = val - 0x20;
				
				// obsługa znaków z shiftem
				val2 = ascii_to_code[val] & 0x80;
				if(val2) {
					val = ascii_to_code[val] & 0x7f;
					input_report_key(input_dev, 0x36, 1);
				} else {
					val = ascii_to_code[val];
				}
				
				// wypisanie znaku
				input_report_key(input_dev, val, 1);
				input_report_key(input_dev, val, 0);
				
				// zakończenie obsługi shiftu
				if(val2) {
					input_report_key(input_dev, 0x36, 0);
				}
				
				// sync dla podsystemu input
				input_sync(input_dev);
			} else {
				printk(KERN_NOTICE "otrzymałem %d jako pojedynczy znak, ale nie wyglada to na znak ASCII\n", val);
			}
			// przeskok do kolejnej pozycji
			i=i+2;
		// gdy mamy to traktować jako keycode
		} else if (buf[i] == '0' && buf[i+1] == 'x') {
			// obliczenie keycode oraz poczatku nastepnej pozycji
			val = simple_strtoul(buf + i, &end, 16);
			i = end - buf + 1;
			
			printk(KERN_NOTICE "otrzymałem keycode %x\n", val);
			
			// wysłanie keycode z uwzglednieniem rozróżnienia nacisnięcie/puszczenie
			if(val & 0x80) {
				input_report_key(input_dev, 0x7f & val, 0);
			} else {
				input_report_key(input_dev, val, 1);
			}
			
			// sync dla podsystemu input
			input_sync(input_dev);
		} else {
			printk(KERN_NOTICE "otrzymałem nadmiarowy znak ... ignoruje\n");
			i++;
		}
	}
	
	return count;
}

static int char_dev_open (struct inode *inode, struct file *file) {
	return 0;
}
