/**
 * Moduł służy do obsługi termometru DS18B20 podłączonego poprzez USB przy pomocy układu
 * FT245BM wg poniższego schematu:
 *
   +----------+
   |   FTDI   |
   |          |                    +---------+
   |       D0 |---[R=4k7]---+      | DS18B20 |
   |       D1 |-------------+      |         |
   |          |             +------|DQ       |
   +----------+                    |         |
                                   |+++++++++|
 *
 * Funkcje obsługi układów FTDI w bit bang mode oraz programowej obsługi OneWire przy
 * pomocy takiego interfejsu zostały wydzielone do osobnych modułów pomocniczych -
 * ftdi_bitbang oraz ftdi_onewire.
 *
 * Numery ROM termometrów konfiguruje się poprzez:
 *   echo "set 2 = {0x28, 0x49, 0xd7, 0x65, 0x1, 0x0, 0x0, 0x48}" > /proc/ftdi_ds18b20-0
 *   echo "del 2" > /proc/ftdi_ds18b20-0
 * Odczyt numeru ROM możliwy gdy moduł załadowany z opcją get_rom_mode=1
**/


#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/usb.h>
#include <linux/fs.h>
#include <linux/proc_fs.h>
#include <linux/slab.h>
#include <asm/uaccess.h>

#include "ftdi_bitbang.h"
#include "ftdi_onewire.h"

#define DEV_DESC "ds18b20 over FTDI bitbang"
#define DEV_PREFIX "ftdi_ds18b20"
#define DEV_NAME DEV_PREFIX "-%d"

#define OUTPUT_BUF_SIZE 100

#define SEND_BUFFOR_SIZE 384 /* FT245BM max 384 */
// konfiguracja związana z używaniem układu FTDI - baudrate, interfejs oraz podłączenia ...
#define BAUDRATE_VALUE 16421 /* baudrate 20000 => w rzeczysistości 20000x16 bajtów/s, bo dla bit bang mnożymy baudrate przez 16 (FTDI "Application Note AN232BM-01"), odpowiada to czasowi trwania pojedyńczego bitu przy wysyłaniu buforowanym 3.125us, co nienajgorzej zgadza się z stanem faktycznym */
#define BAUDRATE_INDEX 0
#define FTDI_INTERFACE 0
#define SEND_PIN 0
#define READ_PIN 1



/// informacje o module
MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("FTDI Bit Bang Driver for DS18B20");
MODULE_AUTHOR("Robert Paciorek");



/// parametry insmod
unsigned int get_rom_mode = 0;
module_param(get_rom_mode, int, 0644);
MODULE_PARM_DESC(get_rom_mode, "while read device return ROM number of connected 1 wire dev\
 instead of temperature value, default is 0 (no)");

unsigned int max_term_per_device = 10;
module_param(max_term_per_device, int, 0644);
MODULE_PARM_DESC(max_term_per_device, "maximum number of ROMs for device, default is 10");



/// skruktura z danymi prywatnymi interfejsu ...
typedef struct {
	struct usb_device *dev;
	struct usb_interface *intf;
	struct proc_dir_entry *proc;
	unsigned char **rom_table;
	unsigned char use;
	unsigned char counter;
	unsigned char counter_max;
} ftdi_ds18b20_priv_data_t;



/// nagłówki funkcji i struktury dla usb_register_dev()
static ssize_t char_dev_read(struct file *file, char __user *buf, size_t count, loff_t *ppos);
static int char_dev_open(struct inode *inode, struct file *file);
static int char_dev_close(struct inode *inode, struct file *file);

static struct file_operations char_dev_conf = {
	.owner	 = THIS_MODULE,
	.read	 = char_dev_read, // tutaj określamy funkcję wywoływaną przy odczycie
	.open	 = char_dev_open, // ... przy otwarciu
	.release = char_dev_close, // ... przy zamykaniu
};

static struct usb_class_driver ftdi_ds18b20_class = {
	.name =         DEV_NAME,
	.fops =         &char_dev_conf,
	.minor_base =   0,
};



/// nagłówki funkcji i struktury dla create_proc_entry()
static ssize_t proc_file_read(struct file *file, char __user *buf, size_t count, loff_t *ppos);
static ssize_t proc_file_write(struct file *file, const char __user *buf, size_t count, loff_t *ppos);
static int proc_file_open(struct inode *inode, struct file *file);
static int proc_file_close(struct inode *inode, struct file *file);

static struct file_operations proc_file_conf = {
	.owner	 = THIS_MODULE,
	.read	 = proc_file_read,
	.write	 = proc_file_write,
	.open	 = proc_file_open,
	.release = proc_file_close,
};



/// funkcje i struktury dla usb_register()
static int ftdi_ds18b20_probe(struct usb_interface *intf, const struct usb_device_id *dev_id) {
	int sts;
	ftdi_ds18b20_priv_data_t *prv_data;
	prv_data = kzalloc(sizeof(*prv_data), GFP_KERNEL);
	if(!prv_data) {
		printk(KERN_ERR DEV_DESC ": error alocate prv_data\n");
		return -ENOMEM;
	}
	
	prv_data->use = 0x00;
	
	sts = usb_register_dev(intf, &ftdi_ds18b20_class);
	if(sts) {
		printk(KERN_ERR DEV_DESC ": error register usb dev\n");
		kfree(prv_data);
		return sts;
	}
	
	printk(KERN_DEBUG DEV_DESC ": device now attached to %s\n", intf->usb_dev->bus_id);
	
	// konfiguracja przez /proc
	if (!get_rom_mode) {
		prv_data->proc = create_proc_entry(intf->usb_dev->bus_id, 0644, NULL);
		if (!prv_data->proc) {
			printk(KERN_ERR "%s: error create proc entry\n", intf->usb_dev->bus_id);
			kfree(prv_data);
			return -ENODEV;
		}
		prv_data->proc->proc_fops = &proc_file_conf;
		prv_data->proc->data = prv_data;
		prv_data->counter_max = 0;
		
		prv_data->rom_table = kzalloc(sizeof(char*) * max_term_per_device, GFP_KERNEL);
		if (!prv_data->rom_table) {
			printk(KERN_ERR "%s: error alocate rom_table\n", intf->usb_dev->bus_id);
			kfree(prv_data);
			return -ENOMEM;
		}
	} else {
		prv_data->proc = NULL;
		prv_data->rom_table = NULL;
		prv_data->counter_max = 1;
	}
	
	prv_data->dev = interface_to_usbdev(intf);
	prv_data->intf = intf;
	
	usb_set_intfdata (intf, prv_data);
	
	printk(KERN_DEBUG "%s: register successful\n", intf->usb_dev->bus_id);
	
	return 0;
}

static void ftdi_ds18b20_disconnect (struct usb_interface *intf) {
	ftdi_ds18b20_priv_data_t *prv_data;
	int i;
	int minor = intf->minor;
	prv_data = usb_get_intfdata(intf);
	
	if (prv_data->rom_table) {
		for (i=0; i<max_term_per_device; i++) {
			if (prv_data->rom_table[i])
				kfree( prv_data->rom_table[i] );
		}
		kfree( prv_data->rom_table );
	}
	if (prv_data->proc)
		remove_proc_entry(intf->usb_dev->bus_id, NULL);
	
	kfree( prv_data );
	usb_set_intfdata(intf, NULL);
	usb_deregister_dev(intf, &ftdi_ds18b20_class);
	
	printk(KERN_DEBUG DEV_NAME ": now disconnected\n", minor);
}

static struct usb_device_id ftdi_ds18b20_id_table [] = {
	{ USB_DEVICE(0x0403, 0x6001) },
	{ },
	{ }
};

static struct usb_driver ftdi_ds18b20_driver = {
	.name = DEV_PREFIX,
	.probe = ftdi_ds18b20_probe,
	.disconnect = ftdi_ds18b20_disconnect,
	.id_table = ftdi_ds18b20_id_table,
	.no_dynamic_id = 1,
};



/// ładowanie i usuwanie sterownika
int ftdi_ds18b20_init(void) {
	int sts;
	
	sts = usb_register(&ftdi_ds18b20_driver);
	if (sts) {
		printk(KERN_ERR DEV_DESC ": error usb_register\n");
		return sts;
	}
	
	return 0;
}
module_init(ftdi_ds18b20_init);

void ftdi_ds18b20_cleanup(void) {
	usb_deregister(&ftdi_ds18b20_driver);
}
module_exit(ftdi_ds18b20_cleanup);



/// ciała funkcji obsługujących plik w proc
static int proc_file_open(struct inode *inode, struct file *file) {
	ftdi_ds18b20_priv_data_t *prv_data = PDE(inode)->data;
	
	if ( test_and_set_bit(1, (void *)&(prv_data->use)) ) {
		printk(KERN_WARNING "%s: proc file arledy open\n", prv_data->intf->usb_dev->bus_id);
		return -EBUSY;
	}
	
	file->private_data = (void*)1;
	
	return 0;
}

static int proc_file_close(struct inode *inode, struct file *file) {
	ftdi_ds18b20_priv_data_t *prv_data = PDE(inode)->data;
	clear_bit(1, (void *)&(prv_data->use));
	
	return 0;
}

static ssize_t proc_file_read(struct file *file, char __user *buf, size_t count, loff_t *ppos) {
	ftdi_ds18b20_priv_data_t *prv_data = PDE(file->f_path.dentry->d_inode)->data;
	unsigned char *address;
	unsigned char str_buf[OUTPUT_BUF_SIZE];
	int i, ret=0, len=0;
	
	
	if ( ! file->private_data )
		return 0;
	else
		file->private_data = (void*)0;
	
	
	for (i=0; i < prv_data->counter_max; i++) {
		address = prv_data->rom_table[i];
		if (address == NULL)
			continue;
		
		len = snprintf(str_buf, OUTPUT_BUF_SIZE,
			"%d = {0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x}\n",
			i, address[0], address[1], address[2], address[3],
			address[4], address[5], address[6], address[7]
		);
		
		if (copy_to_user(buf+ret, str_buf, len)) {
			printk(KERN_ERR "%s: copy_to_user error\n", prv_data->intf->usb_dev->bus_id);
			return -EFAULT;
		}
		
		ret += len;
	}
	
	return ret;
}

static ssize_t proc_file_write(struct file *file, const char __user *buf, size_t count, loff_t *ppos) {
	ftdi_ds18b20_priv_data_t *prv_data = PDE(file->f_path.dentry->d_inode)->data;
	char *name = prv_data->intf->usb_dev->bus_id;
	unsigned char *address;
	unsigned char str_buf[OUTPUT_BUF_SIZE];
	unsigned int  num, data_buf[8];
	int i, j, last, len;
	
	last = 0;
	for (i=0; i<count; i++) {
		if (buf[i] == '\n') {
			len = i-last;
			if (len >= OUTPUT_BUF_SIZE){
				printk(KERN_WARNING "%s: Line too long\n", name);
				return -EINVAL;
			}
			if (copy_from_user(str_buf, buf + last, len)) {
				printk(KERN_ERR "%s: copy_from_user error\n", name);
				return -EFAULT;
			}
			str_buf[i] = '\0';
			last = i+1;
			
			len = sscanf(str_buf, "set %d = {0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x}",
				&num, data_buf, data_buf+1, data_buf+2, data_buf+3,
				data_buf+4, data_buf+5, data_buf+6, data_buf+7
			);
			
			if (len < 9) {
				len = sscanf(str_buf, "del %d", &num);
				
				if (len < 1) {
					printk(KERN_WARNING "%s: Bad line format\n", name);
					return -EINVAL;
				}
				
				if (num >= max_term_per_device){
					printk(KERN_WARNING "%s: Entry number > max_term_per_device\n", name);
					return -EINVAL;
				}
				
				if (prv_data->rom_table[num]) {
					kfree(prv_data->rom_table[num]);
					prv_data->rom_table[num] = NULL;
				}
				if (num + 1 == prv_data->counter_max) {
					while (! prv_data->rom_table[--prv_data->counter_max]);
					prv_data->counter_max++;
				}
			} else {
				if (num >= max_term_per_device){
					printk(KERN_WARNING "%s: Entry number > max_term_per_device\n", name);
					return -EINVAL;
				}
				
				address = prv_data->rom_table[num];
				if(!address) {
					address = kzalloc(sizeof(char) * 8, GFP_KERNEL);
					prv_data->rom_table[num] = address;
				}
				if(!address) {
					printk(KERN_ERR "%s: Error alocate rom_table entry\n", name);
					return -ENOMEM;
				}
				
				for (j=0; j<8; j++) {
					address[j] = (unsigned char)data_buf[j];
				}
				
				if (num >= prv_data->counter_max) {
					prv_data->counter_max = num +1;
				}
			}
		}
	}
	return count;
}


/// ciała funkcji obsługujących urządzenie znakowe
static int char_dev_open(struct inode *inode, struct file *file) {
	int minor;
	struct usb_interface *intf;
	ftdi_ds18b20_priv_data_t *prv_data;
	
	
	// ustalenie interfejsu w oparciu o numer minor otwartego urządzenia
	minor = iminor(inode);
	intf = usb_find_interface(&ftdi_ds18b20_driver, minor);
	if (!intf) {
		printk(KERN_ERR DEV_NAME ": Can't find device for this minor (%d)\n", minor, minor);
		return -ENODEV;
	}
	
	// uzyskanie pelnych danych prywatnych urzadzenia w oparciu o interfejs
	prv_data = usb_get_intfdata(intf);
	
	if ( test_and_set_bit(0, (void *)&(prv_data->use)) ) {
		// bezpośrednie uzycie operacji atomowych jest wydajniejsze od semaforów,
		// a ich stosowanie nie wniosłoby tu nic wartościowego ...
		// operacje na atomic_t są gorsze w tym wypadku operacje binarnych
		// gdyż tamte najpierw modyfikują atomic_t a dopiero potem wykonują test ...
		printk(KERN_WARNING "%s: Arledy open\n", prv_data->intf->usb_dev->bus_id);
		return -EBUSY;
	}
	
	prv_data->counter = 0;
	
	// zapamiętanie tego w danych pliku
	file->private_data = prv_data;
	
	// inicjalizacja układu FTDI w trybie bitbang
	return init_ftdi_bitbang(prv_data->dev, intf, FTDI_INTERFACE, 1<<SEND_PIN,
		BAUDRATE_VALUE, BAUDRATE_INDEX);
}

static int char_dev_close(struct inode *inode, struct file *file) {
	ftdi_ds18b20_priv_data_t *prv_data = file->private_data;
	clear_bit(0, (void *)&(prv_data->use));
	
	return 0;
}


#define FTDI_ERROR_STS(devname, info) {\
	printk(KERN_ERR "%s: " info, devname, sts);\
	if (buffer) kfree(buffer);\
	if (urb) usb_free_urb(urb);\
	return sts;\
}

#define FTDI_ERROR(devname, info, err) {\
	printk(KERN_ERR "%s: " info, devname);\
	if (buffer) kfree(buffer);\
	if (urb) usb_free_urb(urb);\
	return err;\
}

static ssize_t char_dev_read(struct file *file, char __user *buf, size_t count, loff_t *ppos) {
	ftdi_ds18b20_priv_data_t *prv_data = file->private_data;
	char *name = prv_data->intf->usb_dev->bus_id;
	unsigned char *buffer = NULL;
	struct urb *urb = NULL;
	int sts, ret;
	unsigned char *address = NULL;
	unsigned char data_buf[8], str_buf[OUTPUT_BUF_SIZE];
	
	if (prv_data->counter == prv_data->counter_max)
		return 0;
	
	if (!get_rom_mode) {
		address = prv_data->rom_table[prv_data->counter];
		if (address == NULL) {
			prv_data->counter++;
			if (copy_to_user(buf, "", 1))
				FTDI_ERROR(name, "copy_to_user error\n", -EFAULT)
			else
				return 1;
		}
	}
	
	// bufor dla usb_bulk_msg(), usb_fill_bulk_urb()
	buffer = kmalloc(SEND_BUFFOR_SIZE, GFP_ATOMIC);
	if (!buffer) FTDI_ERROR(name, "Can't allocate sending data buffer\n", -ENOMEM)
	
	// bufor dla usb_fill_bulk_urb()
	urb = usb_alloc_urb(0, GFP_KERNEL);
	if (!urb) FTDI_ERROR(name, "Can't allocate UBR buffer\n", -ENOMEM)
	
	
	if (get_rom_mode) {
		sts = onewire_get_rom(prv_data->dev, prv_data->intf, FTDI_INTERFACE, SEND_PIN,
			READ_PIN, urb, buffer, data_buf);
		if (sts<0) FTDI_ERROR_STS(name, "Can't read ROM (error %d)\n")
		
		// sformatowanie wyników
		ret = snprintf(str_buf, OUTPUT_BUF_SIZE,
			"ROM IS: {0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x}\n",
			data_buf[0], data_buf[1], data_buf[2], data_buf[3],
			data_buf[4], data_buf[5], data_buf[6], data_buf[7]
		);
	} else {
		sts = onewire_noaddr_cmd(prv_data->dev, prv_data->intf, FTDI_INTERFACE, SEND_PIN,
			READ_PIN, urb, buffer, 0x44, NULL, 0);
		if (sts<0) FTDI_ERROR_STS(name,
			"Can't send convert temperature (0x44) command (error %d)\n")
		
		msleep(750); // wymóg układu termometru - czas potrzebny na dokonanie konwersji
		
		sts = onewire_addr_cmd(prv_data->dev, prv_data->intf, FTDI_INTERFACE, SEND_PIN,
			READ_PIN, urb, buffer, 0xbe, address, data_buf, 2);
		if (sts<0) FTDI_ERROR_STS(name, "Can't send read (0xbe) command (error %d)\n")
		
		// sformatowanie wyników
		ret = snprintf(str_buf, OUTPUT_BUF_SIZE,
			"%d : {0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x} : %d.%d\n",
			prv_data->counter, address[0], address[1], address[2], address[3],
			address[4], address[5], address[6], address[7],
			(data_buf[1] << 4 | data_buf[0] >> 4), (data_buf[0] & 0x0f) * 625
		);
	}
	
	prv_data->counter++;
	
	// zwolnienie UBR
	usb_free_urb(urb);
	urb = NULL;
	
	// zwolnienie bufora usb_bulk_msg()
	kfree(buffer);
	buffer = NULL;
	
	// zwrócenie wyników
	if (copy_to_user(buf, str_buf, ret))
		FTDI_ERROR(name, "copy_to_user error\n", -EFAULT)
	else
		return ret;
}
