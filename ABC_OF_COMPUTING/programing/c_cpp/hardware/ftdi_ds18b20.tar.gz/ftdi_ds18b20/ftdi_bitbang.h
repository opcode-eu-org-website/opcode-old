#ifndef FTDI_BITBANG_H
#define FTDI_BITBANG_H

#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/usb.h>

#define FTDI_DEVICE_OUT_REQTYPE   0x40
#define FTDI_DEVICE_IN_REQTYPE    0xC0

#define FTDI_RESET_REQUEST        0x00
#define FTDI_SET_BAUDRATE_REQUEST 0x03
#define FTDI_SET_BITMODE_REQUEST  0x0B
#define FTDI_READ_PINS_REQUEST    0x0C

#define FTDI_SND_EP_FROM_INTR(a)  ((a+1)<<1)

#define FTDI_RESET_FULL           0x00
#define FTDI_BITMODE_ON           (1 << 8)

#ifndef FTDI_TIMEOUT
#  define FTDI_TIMEOUT 500
#endif


extern int init_ftdi_bitbang(struct usb_device *dev, struct usb_interface *intf,
	__u16 intf_num, __u8 bitmask, __u16 baudrate_value, __u16 baudrate_index);

/**
 * ftdi_bitbang_read - read FTDI pin state in bit bang mode
 * @dev - pointer to usb_device struct described FTDI device
 * @intf_num - value of usb_control_msg index decide of selected interface
 *             for FT2232C/2232H/4232H chips (other always 0)
 * @buf - pointer to unsigned char, in this variable will be put readed pin state
 **/
#define ftdi_bitbang_read(dev, intf_num, buf) \
	usb_control_msg(dev, usb_rcvctrlpipe(dev, 0), FTDI_READ_PINS_REQUEST,\
	FTDI_DEVICE_IN_REQTYPE, 0, intf_num, buf, 1, FTDI_TIMEOUT)

/**
 * ftdi_bitbang_init - set FTDI pin state in bit bang mode
 * @dev - pointer to usb_device struct described FTDI device
 * @intf_num - value of usb_control_msg index decide of selected interface
 *             for FT2232C/2232H/4232H chips (other always 0)
 * @buf - unsigned char [], with data to send, next byte will be shown on
 *        ftdi out pin with baudrate determinate period
 * @len - numbers of bytes in @buf to send
 **/
#define ftdi_bitbang_send_block(dev, intf_num, buf, len) \
	usb_bulk_msg(dev, usb_sndbulkpipe(dev, FTDI_SND_EP_FROM_INTR(intf_num)),\
 	buf, len, NULL, FTDI_TIMEOUT);

/**
 * ftdi_bitbang_send_prepare_nonblock - set FTDI pin state in bit bang mode
 * @dev - pointer to usb_device struct described FTDI device
 * @intf_num - value of usb_control_msg index decide of selected interface
 *             for FT2232C/2232H/4232H chips (other always 0)
 * @buf - unsigned char [], with data to send, next byte will be shown on
 *        ftdi out pin with baudrate determinate period
 * @len - numbers of bytes in @buf to send
 * @fun - function to call after transfer complete
 **/
#define ftdi_bitbang_send_prepare_nonblock(dev, intf_num, buf, len, ubr, fun) \
	usb_fill_bulk_urb(urb, dev, usb_sndbulkpipe(dev,\
	FTDI_SND_EP_FROM_INTR(intf_num)), buf, len, fun, NULL);

#endif
