#ifndef FTDI_ONEWIRE_H
#define FTDI_ONEWIRE_H

extern int onewire_reset(struct usb_device *dev, __u16 intf_num, __u8 send_pin, uint8_t *buf);

extern int onewire_byte(struct usb_device *dev, struct usb_interface *intf,
	__u16 intf_num, __u8 send_pin, __u8 read_pin, struct urb *urb, uint8_t *buf);

extern int onewire_full_cmd(struct usb_device *dev, struct usb_interface *intf,
	__u16 intf_num, __u8 send_pin, __u8 read_pin, struct urb *urb, uint8_t *buf,
	uint8_t rom_cmd, const uint8_t *rom_data, uint8_t bytes_of_rom_data,
	uint8_t cmd, const uint8_t *request, uint8_t *data,
	uint8_t bytes_of_request, uint8_t bytes_of_reply);

/**
 * onewire_addr_cmd - exec OneWire command on select device
 * @dev - pointer to usb_device struct described FTDI device
 * @intf - pointer to usb_interface struct described interface on FTDI device
 * @intf_num - value of usb_control_msg index decide of selected interface
 *             for FT2232C/2232H/4232H chips (other always 0)
 * @s_pin - number (0..7) of bit used to send data
 * @r_pin - number (0..7) of bit used to recived data
 * @urb - bufor URB (alokowany i zwalniany poza tą funkcją)
 * @buf - bufor danych (alokowany i zwalniany poza tą funkcją), minimal lenght 24 bytes,
 *        byte to write and read bit puts in on buf[0]
 * @cmd - byte represented OneWire command
 * @addr - 8 bytes array of OneWire device ROM adsress
 * @data - buffor for output data
 * @len - number of bytes to read form interface and put into @data
 *
 **/
#define onewire_addr_cmd(dev, intf, intf_num, s_pin, r_pin, ubr, buf, cmd, addr, data, len)\
	onewire_full_cmd(dev, intf, intf_num, s_pin, r_pin, ubr, buf,\
	0x55, addr, 8, cmd, NULL, data, 0, len)

/**
 * onewire_noaddr_cmd - exec OneWire command on all device
 * @dev - pointer to usb_device struct described FTDI device
 * @intf - pointer to usb_interface struct described interface on FTDI device
 * @intf_num - value of usb_control_msg index decide of selected interface
 *             for FT2232C/2232H/4232H chips (other always 0)
 * @s_pin - number (0..7) of bit used to send data
 * @r_pin - number (0..7) of bit used to recived data
 * @urb - bufor URB (alokowany i zwalniany poza tą funkcją)
 * @buf - bufor danych (alokowany i zwalniany poza tą funkcją), minimal lenght 24 bytes,
 *        byte to write and read bit puts in on buf[0]
 * @cmd - byte represented OneWire command
 * @data - buffor for output data
 * @len - number of bytes to read form interface and put into @data
 *
 **/
#define onewire_noaddr_cmd(dev, intf, intf_num, s_pin, r_pin, ubr, buf, cmd, data, len)\
	onewire_full_cmd(dev, intf, intf_num, s_pin, r_pin, ubr, buf,\
	0xcc, NULL, 0, cmd, NULL, data, 0, len)

/**
 * onewire_get_rom - get OneWire ROM
 * @dev - pointer to usb_device struct described FTDI device
 * @intf - pointer to usb_interface struct described interface on FTDI device
 * @intf_num - value of usb_control_msg index decide of selected interface
 *             for FT2232C/2232H/4232H chips (other always 0)
 * @s_pin - number (0..7) of bit used to send data
 * @r_pin - number (0..7) of bit used to recived data
 * @urb - bufor URB (alokowany i zwalniany poza tą funkcją)
 * @buf - bufor danych (alokowany i zwalniany poza tą funkcją), minimal lenght 24 bytes,
 *        byte to write and read bit puts in on buf[0]
 * @data - 8 bytes buffor for output data
 *
 **/
#define onewire_get_rom(dev, intf, intf_num, s_pin, r_pin, ubr, buf, data)\
	onewire_full_cmd(dev, intf, intf_num, s_pin, r_pin, ubr, buf,\
	0x33, NULL, 0, 0xff, NULL, data, 0, 8)

#endif
