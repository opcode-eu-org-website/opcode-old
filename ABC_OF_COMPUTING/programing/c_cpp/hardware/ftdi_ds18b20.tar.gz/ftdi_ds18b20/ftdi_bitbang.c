#include "ftdi_bitbang.h"

// informacje o naszym module
MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("Commons functions module for FTDI Bit Bang Driver");
MODULE_AUTHOR("Robert Paciorek");

/**
 * init_ftdi_bitbang - initialize FTDI device in bit bang mode
 * @dev - pointer to usb_device struct described FTDI device
 * @intf - pointer to usb_interface struct described interface on FTDI device
 * @intf_num - value of usb_control_msg index decide of selected interface
 *             for FT2232C/2232H/4232H chips (other always 0)
 * @bitmask - 8bit bitmask describe pin direction (0 - input, 1 - output)
 * @baudrate_value - usb_control_msg value to set baudrate
 * @baudrate_index - usb_control_msg index to set baudrate
 *
 * for calculate baudrate_value an baudrate_index for given baudrate see
 * source code of ftdi_sio module or libftdi
 **/

int init_ftdi_bitbang(struct usb_device *dev, struct usb_interface *intf,
                      __u16 intf_num, __u8 bitmask,
                      __u16 baudrate_value, __u16 baudrate_index) {
	__u16 bitmode;
	int sts;
	
	sts = usb_control_msg(
		dev, usb_sndctrlpipe(dev, 0),
		FTDI_RESET_REQUEST, FTDI_DEVICE_OUT_REQTYPE,
		FTDI_RESET_FULL, intf_num, NULL, 0, FTDI_TIMEOUT
	);
	if (sts) {
		printk(KERN_ERR "FTDI BITBANG: Can't reset device %s (error %d)\n",
			intf->usb_dev->bus_id, sts);
		return -ENODEV;
	}
	
	sts = usb_control_msg(
		dev, usb_sndctrlpipe(dev, 0),
		FTDI_SET_BAUDRATE_REQUEST, FTDI_DEVICE_OUT_REQTYPE,
		baudrate_value, baudrate_index, NULL, 0, FTDI_TIMEOUT
	);
	if (sts) {
		printk(KERN_ERR "FTDI BITBANG: Can't set baund rate for %s (error %d)\n",
			intf->usb_dev->bus_id, sts);
		return -ENODEV;
	}
	
	bitmode = bitmask | FTDI_BITMODE_ON;
	sts = usb_control_msg(
		dev, usb_sndctrlpipe(dev, 0),
		FTDI_SET_BITMODE_REQUEST, FTDI_DEVICE_OUT_REQTYPE,
		bitmode, intf_num, NULL, 0, FTDI_TIMEOUT
	);
	if (sts) {
		printk(KERN_ERR "FTDI BITBANG: Can't set bit-bang mode for %s (error %d)\n",
			intf->usb_dev->bus_id, sts);
		return -ENODEV;
	}
	
	return 0;
}
EXPORT_SYMBOL_GPL(init_ftdi_bitbang);
