Jest to sterownik do obsługi termometru ds18b20 opartego na interfejsie OneWire z wykorzystaniem układu FTDI FT245BM do emulacji portu OneWire w standardowym komputerze PC. Obsługa protokołu OneWire realizowana programowo z wsparciem od strony FT245BM. Sterownik zrealizowany w postaci zestawu modułów dla Linuxa (testowane na kernelu 2.6.29), odpowiedzialnych za:
* tryb bit-bang
* onewire over bitbang
* ds18b20 over (onewire over bitbang)

Sterownik został zrealizowany w ramach projektu zaliczeniowego na przedmiot "Sterowniki urządzeń - podstawy programowania" prowadzonego w semestrze letnim 2008/9 na Wydziale Elektroniki i Technik Informacyjnych Politechniki Warszawskiej.

Projekt zawiera fragmenty silnie oparte na kodzie jądra Linuxa. Projekt dystrybuowany na zasadach licencji GNU GPL.

Robert Paciorek,
2009-06-15
