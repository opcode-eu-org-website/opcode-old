#include "ftdi_bitbang.h"

#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/delay.h>
#include <linux/completion.h>


// informacje o naszym module
MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("Commons functions module for OneWire over FTDI Bit Bang Driver");
MODULE_AUTHOR("Robert Paciorek");


struct api_context {
	struct completion       done;
	int                     status;
};

static void onewire_bit_ubr_block(struct urb *urb) {
	struct api_context *ctx = urb->context;

	ctx->status = urb->status;
	complete(&ctx->done);
}

/**
 * onewire_bit - send/read single bit over OneWire interface
 * @dev - pointer to usb_device struct described FTDI device
 * @intf - pointer to usb_interface struct described interface on FTDI device
 * @intf_num - value of usb_control_msg index decide of selected interface
 *             for FT2232C/2232H/4232H chips (other always 0)
 * @send_pin - number (0..7) of bit used to send data
 * @read_pin - number (0..7) of bit used to recived data
 * @urb - bufor URB (alokowany i zwalniany poza tą funkcją)
 * @buf - bufor danych (alokowany i zwalniany poza tą funkcją), minimal lenght 24 bytes,
 *        bit to write and read bit puts in on bit 0 of buf[0]
 *
 **/
int onewire_bit(struct usb_device *dev, struct usb_interface *intf, __u16 intf_num,
                __u8 send_pin, __u8 read_pin, struct urb *urb, uint8_t *buf) {
	uint8_t i, val;
	struct api_context ctx;
	int sts;
	
	// przygotowanie zawartiości buf w zaleznosci od buf[0] wysylamy albo bit 1, albo bit 0
	val = (buf[0] & 1) << send_pin;
	// okolo 8us stanu niskiego (wymagane: 1-15us)
	buf[0] = 0; buf[1] = 0;
	// okolo 65us stanu odpowiadającemu wartości logicznej bitu
	// standard wymaga aby cały czas bitu był od 60us do 120us (mamy około 72us)
	for (i=2; i<23; i++) {
		buf[i] = val;
	}
	// na koniec ustawienie na stan wysoki
	buf[23] = (1<<send_pin);
	
	// wypelnienie URB
	ftdi_bitbang_send_prepare_nonblock(dev, intf_num, buf, 24, urb, onewire_bit_ubr_block);
	
	init_completion(&ctx.done);
	urb->context = &ctx;
	
	// zlecenie obsługi URB
	sts = usb_submit_urb(urb, GFP_NOIO);
	if (sts) {
		printk(KERN_ERR "FTDI OneWire (%s): error usb_submit_urb %d\n",
			intf->usb_dev->bus_id, sts);
		return sts;
	}
	
	// czekamy 15us
	udelay(15);
	
	// robimy odczyt
	sts = ftdi_bitbang_read(dev, intf_num, &i);
	if (sts<0)  {
		printk(KERN_ERR "FTDI OneWire (%s): can't read (error %d)\n",
			intf->usb_dev->bus_id, sts);
		return sts;
	}
	
	// tak zeby skonczyl sie cylk 1wire i układ FTDI skończył wysyłanie ...
	// bo na opoznieniu zwiazanym z wysylaniem URB nie można polegać ...
	udelay(70);
	
	// czekamy na zakonczenie przetwarzania urb
	if (!wait_for_completion_timeout(&ctx.done, msecs_to_jiffies(100))) {
		usb_kill_urb(urb);
		printk(KERN_ERR "FTDI OneWire (%s): Error waiting for finish urb transfer\n", 
			 intf->usb_dev->bus_id);
		return (ctx.status == -ENOENT ? -ETIMEDOUT : ctx.status);
	}
	
	// konczymy - wartosc odczytana umieszczmy w buf[0]
	buf[0] = i >> read_pin;
	
	// zwracamy status
	return 0;
}



/**
 * onewire_reset - reset OneWire bus
 * @dev - pointer to usb_device struct described FTDI device
 * @intf_num - value of usb_control_msg index decide of selected interface
 *             for FT2232C/2232H/4232H chips (other always 0)
 * @send_pin - number (0..7) of bit used to send data
 * @urb - bufor URB (alokowany i zwalniany poza tą funkcją)
 * @buf - bufor danych (alokowany i zwalniany poza tą funkcją), minimal lenght 1 byte,
 *
 **/
int onewire_reset(struct usb_device *dev, __u16 intf_num, __u8 send_pin, uint8_t *buf) {
	int sts;
	
	buf[0] = 0x00;
	sts = ftdi_bitbang_send_block(dev, intf_num, buf, 1);
	if (sts<0) return sts;
	
	// dla pewności gdyż na opoznieniu zwiazanym z wysylaniem URB nie można polegać ...
	udelay(480);
	
	// stan ustawiany bezposrednio usb_bulk_msg() trwa okolo 1ms
	// aby uzyskac krótsze odcinki należy wypełnić więcej bajtów bufora wysyłanego usb_bulk_msg()
	// - max 384 dla FT245BM, układ będzie samodzielnie wystawiał kolejne bajty w tempie zadanym
	// przez baund rate - patrz onewire_bit()
	
	buf[0] = 0x01;
	return ftdi_bitbang_send_block(dev, intf_num, buf, 1);
	
	// dla pewności gdyż na opoznieniu zwiazanym z wysylaniem URB nie można polegać ...
	udelay(480);
}
EXPORT_SYMBOL_GPL(onewire_reset);



/**
 * onewire_byte - send/read single bit over OneWire interface
 * @dev - pointer to usb_device struct described FTDI device
 * @intf - pointer to usb_interface struct described interface on FTDI device
 * @intf_num - value of usb_control_msg index decide of selected interface
 *             for FT2232C/2232H/4232H chips (other always 0)
 * @send_pin - number (0..7) of bit used to send data
 * @read_pin - number (0..7) of bit used to recived data
 * @urb - bufor URB (alokowany i zwalniany poza tą funkcją)
 * @buf - bufor danych (alokowany i zwalniany poza tą funkcją), minimal lenght 24 bytes,
 *        byte to write and read bit puts in on buf[0]
 *
 **/
int onewire_byte(struct usb_device *dev, struct usb_interface *intf, __u16 intf_num,
                 __u8 send_pin, __u8 read_pin, struct urb *urb, uint8_t *buf) {
	uint8_t i, b;
	int sts;
	
	b=buf[0];
	for (i=8; i; i--) {
		buf[0] = (b & 0x01) ? 0xff : 0x00;
		sts = onewire_bit(dev, intf, intf_num, send_pin, read_pin, urb, buf);
		if (sts) {
			return sts;
		}
		b = ( buf[0] << 7 ) | ( b >> 1 );
		// w najstarszy bit zapisuje zczytana wartosc
		// wykonuje binarne lub z
		// poprzednia wartoscia b przesunieta o 1 w prawo
	}
	buf[0]=b;
	
	return 0;
}
EXPORT_SYMBOL_GPL(onewire_byte);



/**
 * onewire_cmd - exec OneWire command
 * @dev - pointer to usb_device struct described FTDI device
 * @intf - pointer to usb_interface struct described interface on FTDI device
 * @intf_num - value of usb_control_msg index decide of selected interface
 *             for FT2232C/2232H/4232H chips (other always 0)
 * @send_pin - number (0..7) of bit used to send data
 * @read_pin - number (0..7) of bit used to recived data
 * @urb - bufor URB (alokowany i zwalniany poza tą funkcją)
 * @buf - bufor danych (alokowany i zwalniany poza tą funkcją), minimal lenght 24 bytes,
 *        byte to write and read bit puts in on buf[0]
 * @rom_cmd - byte represented OneWire ROM command
 * @rom_data - addional ROM request buffor (e.g. device address)
 * @bytes_of_rom_data - number of bytes to read form interface and put into @rom_data
 * @cmd - byte represented OneWire command
 * @request - addional request buffor
 * @data - buffor for output data
 * @bytes_of_request - number of bytes in @request to send as addional command or request
 * @bytes_of_reply - number of bytes to read form interface and put into @data
 *
 **/
int onewire_full_cmd(struct usb_device *dev, struct usb_interface *intf,
                     __u16 intf_num, __u8 send_pin,
                     __u8 read_pin, struct urb *urb, uint8_t *buf,
                     uint8_t rom_cmd, const uint8_t *rom_data, uint8_t bytes_of_rom_data,
                     uint8_t cmd, const uint8_t *request, uint8_t *data,
                     uint8_t bytes_of_request, uint8_t bytes_of_reply) {
	uint8_t i;
	int sts;
	
	sts = onewire_reset(dev, intf_num, send_pin, buf);
	if (sts<0) return sts;
	
	buf[0] = rom_cmd;
	for(i=0; ; i++) {
		sts = onewire_byte(dev, intf, intf_num, send_pin, read_pin, urb, buf);
		if (sts) return sts;
		
		if (i < bytes_of_rom_data)
			buf[0] = rom_data[i];
		else
			break;
	}
	
	if (cmd != 0xff) {
		buf[0] = cmd;
		for(i=0; ; i++) {
			sts = onewire_byte(dev, intf, intf_num, send_pin, read_pin, urb, buf);
			if (sts) return sts;
			
			if (i < bytes_of_request)
				buf[0] = request[i];
			else
				break;
		}
	}
	
	// odebranie odpowiedzi
	for (i = 0; i<bytes_of_reply ; i++) {
		buf[0] = 0xff;
		sts = onewire_byte(dev, intf, intf_num, send_pin, read_pin, urb, buf);
		if (sts) return sts;
		data[i]=buf[0];
	}
	
	return sts;
}
EXPORT_SYMBOL_GPL(onewire_full_cmd);
