orginal version download from: http://commons.wikimedia.org/wiki/Image:Philips_PM5544.svg
modyfited by: Robert Paciorek (http://www.opcode.eu.org/bercik/)

(C) Copyright 2008 by:
	* Xfigpower (http://commons.wikimedia.org/wiki/User:Xfigpower)
	* Ebnz (http://commons.wikimedia.org/wiki/User:Ebnz)
on licence:
	* GNU Free Documentation License 1.2 or any later
	or
	* Creative Commons Attribution 2.5
