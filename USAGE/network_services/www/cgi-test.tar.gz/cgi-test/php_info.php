<?php
	phpinfo();
?> 
